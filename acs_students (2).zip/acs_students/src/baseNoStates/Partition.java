package baseNoStates;

public class Partition {
  private String name;
  private String description;
  private Object data;

  public Partition(String name, String description, Object data) {
    this.name = name;
    this.description = description;
    this.data = data;
  }

}
