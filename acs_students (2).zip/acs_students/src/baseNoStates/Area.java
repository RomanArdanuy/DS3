package baseNoStates;

public abstract class Area {


}
